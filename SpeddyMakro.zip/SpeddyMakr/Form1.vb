﻿Public Class Form1
    Public Declare Function GetAsyncKeyState Lib "user32" (ByVal vKey As Integer) As Int16
    Private Sub baslat_Click(sender As Object, e As EventArgs) Handles baslat.Click
        Label2.Text = "Aktif"
        Label2.ForeColor = Color.LimeGreen
        If CheckBox1.Checked Then
            Timer1.Start()

        Else
            Timer1.Stop()
        End If
        If CheckBox2.Checked Then
            Timer2.Start()
        Else
            Timer2.Stop()
        End If
        If CheckBox3.Checked Then
            Timer3.Start()
        Else
            Timer3.Stop()
        End If
    End Sub

    Private Sub durdur_Click(sender As Object, e As EventArgs) Handles durdur.Click
        Label2.Text = "Pasif"
        Label2.ForeColor = Color.Maroon
        Timer1.Stop()
        Timer2.Stop()
        Timer3.Stop()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        If GetAsyncKeyState(Keys.E) Then
            SendKeys.Send("WWWWW")
        End If
    End Sub

    Private Sub TrackBar1_Scroll(sender As Object, e As EventArgs) Handles TrackBar1.Scroll
        Timer1.Interval = TrackBar1.Value
    End Sub

    Private Sub TrackBar2_Scroll(sender As Object, e As EventArgs) Handles TrackBar2.Scroll
        Timer2.Interval = TrackBar2.Value
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        If GetAsyncKeyState(Keys.Q) Then
            SendKeys.Send("AAAAA")
        End If
    End Sub

    Private Sub Timer3_Tick(sender As Object, e As EventArgs) Handles Timer3.Tick
        If GetAsyncKeyState(Keys.R) Then
            SendKeys.Send("        ")
        End If
    End Sub

    Private Sub ac_Tick(sender As Object, e As EventArgs) Handles ac.Tick
        If GetAsyncKeyState(Keys.F6) Then
            baslat.PerformClick()
        End If
    End Sub

    Private Sub kapat_Tick(sender As Object, e As EventArgs) Handles kapat.Tick
        If GetAsyncKeyState(Keys.F7) Then
            durdur.PerformClick()
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Hide()
        gizle.Visible = True
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub gizle_MouseDoubleClick(sender As Object, e As MouseEventArgs) Handles gizle.MouseDoubleClick
        Me.Show()
    End Sub

    Private Sub gizletimer_Tick(sender As Object, e As EventArgs) Handles gizletimer.Tick
        If GetAsyncKeyState(Keys.F8) Then
            Button1.PerformClick()
        End If
        gizletimer.Stop()
        gostertimer.Start()



        gostertimer.Interval = 1000

        gostertimer.Interval = 500

        gostertimer.Interval = 100

        gostertimer.Interval = 270
    End Sub

    Private Sub gostertimer_Tick(sender As Object, e As EventArgs) Handles gostertimer.Tick
        If GetAsyncKeyState(Keys.F8) Then
            Me.Show()
        End If

        gizletimer.Start()

    End Sub
End Class
